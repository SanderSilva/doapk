(function(root) {
  function getDifficulty(score, age = 5) {
    const pace = age <= 3 ? 12 : age === 4 ? 10 : age === 5 ? 8 : age <= 7 ? 6 : age <= 9 ? 5 : 4;
    return Math.min(15, 1 + Math.floor(Math.max(0, score) / pace));
  }
  function makeQuestion(level, operation = 'mix', random = Math.random, age = 5) {
    const ageCap = age <= 3 ? 5 : age === 4 ? 8 : age === 5 ? 12 : age <= 7 ? 20 : age <= 9 ? 50 : 100;
    const ageStart = age <= 3 ? 3 : age === 4 ? 4 : age <= 6 ? 5 : age <= 8 ? 8 : 10;
    const step = age <= 3 ? .5 : age <= 6 ? 1.7 : age <= 8 ? 4 : 7;
    const max = Math.min(ageCap, Math.max(3, Math.floor(ageStart + (Math.max(1, level) - 1) * step)));
    const op = operation === 'mix' ? (random() < 0.5 ? '+' : '−') : operation;
    let a = 1 + Math.floor(random() * max);
    let b = 1 + Math.floor(random() * max);
    if (op === '−' && b > a) [a, b] = [b, a];
    return { a, b, op, answer: op === '+' ? a + b : a - b };
  }
  function isCorrect(question, value) { return Number(value) === question.answer; }
  // Cada 100 pontos acumulados avança um nível; o máximo é 100.
  function getPlayerLevel(totalPoints) { return Math.min(100, 1 + Math.floor(Math.max(0, Number(totalPoints) || 0) / 100)); }
  // Três vidas no máximo; a cada cinco operações concluídas, recupera uma vida perdida.
  function loseLife(lives, maxLives = 3) { return Math.max(0, Math.min(maxLives, Number(lives) || 0) - 1); }
  function completeOperation(lives, operations, maxLives = 3, restoreEvery = 5) {
    const nextOperations = Math.max(0, Number(operations) || 0) + 1;
    let nextLives = Math.max(0, Math.min(maxLives, Number(lives) || 0));
    const recovered = nextOperations % restoreEvery === 0 && nextLives < maxLives;
    if (recovered) nextLives++;
    return { lives: nextLives, operations: nextOperations, recovered };
  }
  // Encaixe automático: prioriza linhas horizontais completas e quase completas.
  function findAutoPlacement(board, cells, cols, rows, mode = 'best') {
    if (!Array.isArray(cells) || !cells.length) return null;
    const width = Math.max(...cells.map(c => c[0])) + 1;
    const height = Math.max(...cells.map(c => c[1])) + 1;
    if (width > cols || height > rows) return null;
    const collides = (x, y) => cells.some(([cx, cy]) => {
      const bx = x + cx, by = y + cy;
      return bx < 0 || bx >= cols || by < 0 || by >= rows || Boolean(board[by]?.[bx]);
    });
    const candidates = [];
    for (let x = 0; x <= cols - width; x++) {
      // A peça cai verticalmente; não pode atravessar blocos já colocados.
      if (collides(x, 0)) continue;
      let y = 0;
      while (y + height < rows && !collides(x, y + 1)) y++;
      if (collides(x, y)) continue;
      const next = board.map(row => row.slice());
      cells.forEach(([cx, cy]) => { next[y + cy][x + cx] = '#'; });
      const rowFill = next.map(row => row.filter(Boolean).length);
      const cleared = rowFill.filter(n => n === cols).length;
      const almost = rowFill.filter(n => n === cols - 1).length;
      const close = rowFill.filter(n => n === cols - 2).length;
      const remaining = next.filter(row => !row.every(Boolean));
      while (remaining.length < rows) remaining.unshift(Array(cols).fill(null));
      let holes = 0, aggregateHeight = 0, maxHeight = 0, roughness = 0;
      const heights = [];
      for (let col = 0; col < cols; col++) {
        let seenBlock = false, colHeight = 0;
        for (let row = 0; row < rows; row++) {
          if (remaining[row][col]) { seenBlock = true; colHeight = rows - row; }
          else if (seenBlock) holes++;
        }
        heights.push(colHeight);
        aggregateHeight += colHeight;
        maxHeight = Math.max(maxHeight, colHeight);
      }
      for (let col = 1; col < cols; col++) roughness += Math.abs(heights[col] - heights[col - 1]);
      // Completar uma linha tem prioridade absoluta; quase completar também ajuda.
      const score = cleared * 100000 + almost * 1200 + close * 220
        - holes * 160 - aggregateHeight * 3 - maxHeight * 8 - roughness * 5;
      candidates.push({ x, y, score, cleared, almost, close });
    }
    if (!candidates.length) return null;
    candidates.sort((a, b) => mode === 'bad' ? a.score - b.score : b.score - a.score);
    return candidates[0];
  }

  if (typeof module !== 'undefined' && module.exports) module.exports = { makeQuestion, isCorrect, getDifficulty, findAutoPlacement, getPlayerLevel, loseLife, completeOperation };
  root.MathGame = { makeQuestion, isCorrect, getDifficulty, findAutoPlacement, getPlayerLevel, loseLife, completeOperation };
})(typeof window !== 'undefined' ? window : globalThis);

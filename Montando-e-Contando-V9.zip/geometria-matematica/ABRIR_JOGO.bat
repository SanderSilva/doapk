﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Montando e Contando V9 - Abrir jogo
where node >nul 2>nul || (echo Instale Node.js LTS em https://nodejs.org/ & pause & exit /b 1)
if not exist node_modules (echo Instalando dependencias na primeira execucao... & call npm install || goto erro)
call npm start
if errorlevel 1 goto erro
exit /b 0
:erro
echo Nao foi possivel abrir. Confira se Node.js esta instalado e tente novamente.
pause

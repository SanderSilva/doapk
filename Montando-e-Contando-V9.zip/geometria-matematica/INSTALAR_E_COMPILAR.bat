﻿@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title Pecas da Matematica V6 - Compilar Windows
where node >nul 2>nul || (echo Instale Node.js LTS em https://nodejs.org/ & pause & exit /b 1)
echo [1/3] Instalando dependencias...
call npm install || goto erro
echo [2/3] Executando testes...
call npm test || goto erro
echo [3/3] Gerando executavel portatil Windows x64...
call npm run dist || goto erro
echo CONCLUIDO! Veja a pasta release.
explorer "%CD%\release"
pause
exit /b 0
:erro
echo Falha na instalacao, nos testes ou na compilacao. Leia as mensagens acima.
pause
exit /b 1

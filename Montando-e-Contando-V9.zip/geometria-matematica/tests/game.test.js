const test = require('node:test');
const assert = require('node:assert/strict');
const { makeQuestion, isCorrect, getDifficulty, findAutoPlacement, getPlayerLevel, loseLife, completeOperation } = require('../src/game.js');
test('gera uma soma com resultado coerente', () => { const q=makeQuestion(1,'+',()=>0.2); assert.equal(q.op,'+'); assert.equal(q.answer,q.a+q.b); });
test('subtração não produz resultado negativo', () => { for(let i=0;i<20;i++){const q=makeQuestion(3,'−',Math.random);assert.ok(q.a>=q.b);assert.equal(q.answer,q.a-q.b);} });
test('valida resposta correta e incorreta', () => {const q={answer:4};assert.equal(isCorrect(q,'4'),true);assert.equal(isCorrect(q,3),false);});
test('dificuldade aumenta gradualmente e tem limite', () => {assert.equal(getDifficulty(0),1);assert.equal(getDifficulty(16),3);assert.equal(getDifficulty(999),15);});

test('questões respeitam faixa inicial por idade', () => { const q=makeQuestion(1,'+',()=>0.99,3); assert.ok(q.a<=3 && q.b<=3); });
test('dificuldade é mais gradual para crianças menores', () => { assert.equal(getDifficulty(12,3),2); assert.equal(getDifficulty(12,6),3); });

test('idade até 10 anos permite contas maiores e níveis progressivos', () => { const q=makeQuestion(5,'+',Math.random,10); assert.ok(q.a<=100 && q.b<=100); assert.ok(getDifficulty(100,10)>getDifficulty(0,10)); });
test('dificuldade fica limitada mesmo em partidas longas', () => { assert.equal(getDifficulty(99999,10),15); });


test('encaixe automático sempre encontra uma posição legal para uma peça simples', () => {
  const board = Array.from({length: 6}, () => Array(5).fill(null));
  const p = findAutoPlacement(board, [[0,0]], 5, 6, 'best');
  assert.ok(p); assert.equal(p.y, 5); assert.ok(p.x >= 0 && p.x < 5);
});

test('encaixe automático evita células ocupadas', () => {
  const board = Array.from({length: 4}, () => Array(4).fill(null));
  board[3] = ['x','x','x',null];
  const p = findAutoPlacement(board, [[0,0]], 4, 4, 'best');
  assert.ok(p); assert.equal(p.x, 3); assert.equal(p.y, 3);
});

test('encaixe correto prioriza completar uma linha horizontal', () => {
  const board = Array.from({length: 6}, () => Array(5).fill(null));
  board[5] = ['x', 'x', 'x', 'x', null];
  const p = findAutoPlacement(board, [[0,0]], 5, 6, 'best');
  assert.ok(p);
  assert.equal(p.x, 4);
  assert.equal(p.cleared, 1);
});

test('encaixe de resposta errada evita completar linha quando há outra posição', () => {
  const board = Array.from({length: 6}, () => Array(5).fill(null));
  board[5] = ['x', 'x', 'x', 'x', null];
  const p = findAutoPlacement(board, [[0,0]], 5, 6, 'bad');
  assert.ok(p);
  assert.notEqual(p.x, 4);
  assert.equal(p.cleared, 0);
});

test('encaixe retorna null quando nenhuma posição legal existe', () => {
  const board = Array.from({length: 3}, () => Array(3).fill('x'));
  assert.equal(findAutoPlacement(board, [[0,0]], 3, 3, 'best'), null);
});

test('nível do perfil sobe a cada 100 pontos acumulados e para no 100', () => {
  assert.equal(getPlayerLevel(0), 1);
  assert.equal(getPlayerLevel(99), 1);
  assert.equal(getPlayerLevel(100), 2);
  assert.equal(getPlayerLevel(999), 10);
  assert.equal(getPlayerLevel(9900), 100);
  assert.equal(getPlayerLevel(25000), 100);
});


test('vida perdida reduz corações sem ficar abaixo de zero', () => { assert.equal(loseLife(3),2); assert.equal(loseLife(1),0); assert.equal(loseLife(0),0); });
test('recupera um coração a cada cinco operações, sem passar de três vidas', () => { assert.deepEqual(completeOperation(2,4),{lives:3,operations:5,recovered:true}); assert.deepEqual(completeOperation(3,4),{lives:3,operations:5,recovered:false}); assert.deepEqual(completeOperation(1,2),{lives:1,operations:3,recovered:false}); });
